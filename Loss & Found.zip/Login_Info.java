public class Login_Info {
    ///E---
    private String F_username="founder";
    private String F_password= "12";
    private String L_username="loss";
    private String L_password="12"   ;

    public String getF_username() {
        return F_username;
    }

    public void setF_username(String f_username) {
        F_username = f_username;
    }

    public String getF_password() {
        return F_password;
    }

    public void setF_password(String f_password) {
        F_password = f_password;
    }

    public String getL_username() {
        return L_username;
    }

    public void setL_username(String l_username) {
        L_username = l_username;
    }

    public String getL_password() {
        return L_password;
    }

    public void setL_password(String l_password) {
        L_password = l_password;
    }
}
